﻿using System;
using System.Data.SQLite;
using System.IO;
using PackageConsole.Models;
using NLog;

namespace PackageConsole.Data
{
    public static class SqlitePackageHelper
    {
        private static readonly Logger Logger = LogManager.GetLogger(nameof(SqlitePackageHelper));

        private static readonly string LocalDbPath = PathManager.MetadataDb;
        private static readonly string CentralDbPath = Path.Combine(
            Path.GetDirectoryName(PathManager.CentralMetadataDb) ?? string.Empty,
            Environment.UserName + "_packages.db"
        );

        static SqlitePackageHelper()
        {
            try
            {
                InitializeDatabase(LocalDbPath);
                InitializeDatabase(CentralDbPath);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Failed to initialize PackageMetadata databases.");
            }
        }

        private static void InitializeDatabase(string path)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                using var conn = new SQLiteConnection($"Data Source={path};Version=3;");
                conn.Open();

                string createTable = @"
                    CREATE TABLE IF NOT EXISTS PackageMetadata (
                        AppKeyID TEXT PRIMARY KEY,
                        AppName TEXT,
                        AppVersion TEXT,
                        ProductCode TEXT,
                        Vendor TEXT,
                        DRMBuild TEXT,
                        RebootOption TEXT,
                        InstallerType TEXT,
                        InstallerFile TEXT,
                        SubmittedBy TEXT,
                        SubmittedOn TEXT,
                        PackageIniText TEXT
                    );";

                using var cmd = new SQLiteCommand(createTable, conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Logger.Warn(ex, $"Unable to initialize database at {path}");
            }
        }

        public static void UpsertPackageMetadata(PackageInfo package)
        {
            try
            {
                WriteToDatabase(LocalDbPath, package);
                BackupToCentralDb();
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Failed to upsert package metadata.");
            }
        }

        private static void WriteToDatabase(string dbPath, PackageInfo package)
        {
            using var conn = new SQLiteConnection($"Data Source={dbPath};Version=3;");
            conn.Open();

            string upsert = @"
                INSERT INTO PackageMetadata (
                    AppKeyID, AppName, AppVersion, ProductCode, Vendor, DRMBuild,
                    RebootOption, InstallerType, InstallerFile, SubmittedBy, SubmittedOn, PackageIniText)
                VALUES (
                    @AppKeyID, @AppName, @AppVersion, @ProductCode, @Vendor, @DRMBuild,
                    @RebootOption, @InstallerType, @InstallerFile, @SubmittedBy, @SubmittedOn, @PackageIniText)
                ON CONFLICT(AppKeyID) DO UPDATE SET
                    AppName = excluded.AppName,
                    AppVersion = excluded.AppVersion,
                    ProductCode = excluded.ProductCode,
                    Vendor = excluded.Vendor,
                    DRMBuild = excluded.DRMBuild,
                    RebootOption = excluded.RebootOption,
                    InstallerType = excluded.InstallerType,
                    InstallerFile = excluded.InstallerFile,
                    SubmittedBy = excluded.SubmittedBy,
                    SubmittedOn = excluded.SubmittedOn,
                    PackageIniText = excluded.PackageIniText;";

            using var cmd = new SQLiteCommand(upsert, conn);
            cmd.Parameters.AddWithValue("@AppKeyID", package.AppKeyID);
            cmd.Parameters.AddWithValue("@AppName", package.AppName);
            cmd.Parameters.AddWithValue("@AppVersion", package.AppVersion);
            cmd.Parameters.AddWithValue("@ProductCode", package.ProductCode);
            cmd.Parameters.AddWithValue("@Vendor", package.Vendor);
            cmd.Parameters.AddWithValue("@DRMBuild", package.DRMBuild);
            cmd.Parameters.AddWithValue("@RebootOption", package.RebootOption);
            cmd.Parameters.AddWithValue("@InstallerType", package.InstallerType);
            cmd.Parameters.AddWithValue("@InstallerFile", package.InstallerFile);
            cmd.Parameters.AddWithValue("@SubmittedBy", package.SubmittedBy);
            cmd.Parameters.AddWithValue("@SubmittedOn", package.SubmittedOn.ToString("yyyy-MM-dd HH:mm:ss"));
            cmd.Parameters.AddWithValue("@PackageIniText", package.PackageIniText);

            cmd.ExecuteNonQuery();
            Logger.Info($"✅ Package metadata upserted into DB: {dbPath}");
        }

        private static void BackupToCentralDb()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(CentralDbPath));

                using var sourceConn = new SQLiteConnection($"Data Source={LocalDbPath};Version=3;");
                using var targetConn = new SQLiteConnection($"Data Source={CentralDbPath};Version=3;");

                sourceConn.Open();
                targetConn.Open();

                sourceConn.BackupDatabase(targetConn, "main", "main", -1, null, 0);
                Logger.Info("✅ PackageMetadata DB backup completed to central.");

                // Fallback: raw file copy for safety
                File.Copy(LocalDbPath, CentralDbPath, true);
                Logger.Info("✅ PackageMetadata DB also copied via File.Copy fallback.");
            }
            catch (Exception ex)
            {
                Logger.Warn(ex, "❌ Failed to backup PackageMetadata DB to central location.");
            }
        }

        public static void UpdateIniTextOnly(string iniFilePath)
        {
            try
            {
                var lines = File.ReadAllLines(iniFilePath);
                var iniText = File.ReadAllText(iniFilePath);
                string appKey = lines.FirstOrDefault(line => line.StartsWith("APPKEYID=", StringComparison.OrdinalIgnoreCase))?.Split('=')[1]?.Trim();

                if (string.IsNullOrWhiteSpace(appKey))
                {
                    Logger.Warn("APPKEYID not found in INI file. Skipping metadata update.");
                    return;
                }

                using var conn = new SQLiteConnection($"Data Source={LocalDbPath};Version=3;");
                conn.Open();

                string update = @"
                    UPDATE PackageMetadata
                    SET PackageIniText = @PackageIniText, SubmittedOn = @SubmittedOn
                    WHERE AppKeyID = @AppKeyID;";

                using var cmd = new SQLiteCommand(update, conn);
                cmd.Parameters.AddWithValue("@AppKeyID", appKey);
                cmd.Parameters.AddWithValue("@PackageIniText", iniText);
                cmd.Parameters.AddWithValue("@SubmittedOn", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                int rows = cmd.ExecuteNonQuery();

                if (rows == 0)
                    Logger.Warn("No matching AppKeyID found to update INI text.");
                else
                    Logger.Info($"✅ INI text updated for AppKeyID: {appKey}");

                File.Copy(LocalDbPath, CentralDbPath, true);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Failed to update PackageIniText.");
            }
        }

        public static List<PackageInfo> GetAllPackages()
        {
            var packages = new List<PackageInfo>();
            try
            {
                using var conn = new SQLiteConnection($"Data Source={PathManager.MetadataDb};Version=3;");
                conn.Open();

                string query = "SELECT * FROM PackageMetadata ORDER BY SubmittedOn DESC;";
                using var cmd = new SQLiteCommand(query, conn);
                using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var pkg = new PackageInfo
                    {
                        AppKeyID = reader["AppKeyID"].ToString(),
                        AppName = reader["AppName"].ToString(),
                        AppVersion = reader["AppVersion"].ToString(),
                        ProductCode = reader["ProductCode"].ToString(),
                        Vendor = reader["Vendor"].ToString(),
                        DRMBuild = reader["DRMBuild"].ToString(),
                        RebootOption = reader["RebootOption"].ToString(),
                        InstallerType = reader["InstallerType"].ToString(),
                        InstallerFile = reader["InstallerFile"].ToString(),
                        SubmittedBy = reader["SubmittedBy"].ToString(),
                        SubmittedOn = DateTime.Parse(reader["SubmittedOn"].ToString()),
                        PackageIniText = reader["PackageIniText"].ToString()
                    };
                    packages.Add(pkg);
                }
            }
            catch (Exception ex)
            {
                Logger.Warn(ex, "Failed to load packages from metadata DB.");
            }

            return packages;
        }

    }
}
