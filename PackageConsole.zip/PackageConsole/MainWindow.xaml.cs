﻿using Microsoft.Win32;
using System.Diagnostics;
using System.Numerics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Timers;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NLog;
using Microsoft.Web.WebView2.Core;
using System.Windows.Media.Animation;
using System.IO;
using Timer = System.Timers.Timer;
using PackageConsole;

public partial class App : Application
{
    private static readonly Logger Logger = LogManager.GetLogger(nameof(MainWindow));
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        Logger.Info("Application started");
    }
    protected override void OnExit(ExitEventArgs e)
    {
        Logger.Info("Application exited");
        base.OnExit(e);
    }
}

namespace PackageConsole
{
    public partial class MainWindow : Window
    {
        private Timer _timer;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        
        public MainWindow()
        {
            InitializeComponent();
            Logger.Info("MainWindow initialized.");
            LoadUserDetails();
            StartMarqueeUpdate();
            StartMarquee();
            string currentUser = Environment.UserName.ToLower();
            if (!AppUserRoles.DevUsers.Contains(currentUser))
            {
                TestingButton.Visibility = Visibility.Collapsed;
                Logger.Info($"Testing page hidden for non-Dev user: {currentUser}");
            }
            else
            {
                Logger.Info($"Testing page visible for Dev user: {currentUser}");
            }
            MainContentArea.Navigate(new HomePage());
            Sidebar.Visibility = Visibility.Hidden;
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            StartMarquee();
        }


        private void StartMarqueeUpdate()
        {
            _timer = new Timer(5000); // Update every 5 seconds
            _timer.Elapsed += UpdateMarqueeText;
            _timer.Start();
        }

        private void UpdateMarqueeText(object sender, ElapsedEventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                // PathManager.BasePackagePath\Docs\Updates.txt
                string filePath = @"\\nasdslapps001\drm_pkging\Team\TeamUtils\PackageConsole\Docs\Updates.txt";
                if (File.Exists(filePath))
                {
                    MarqueeText.Text = File.ReadAllText(filePath);
                }
            });
        }

        private void StartMarquee()
        {
            double from = MainContentArea.ActualWidth;
            double to = -MarqueeText.ActualWidth;

            DoubleAnimation marqueeAnimation = new DoubleAnimation
            {
                From = from,
                To = to,
                Duration = new Duration(TimeSpan.FromSeconds(20)),
                RepeatBehavior = RepeatBehavior.Forever
            };

            MarqueeText.BeginAnimation(Canvas.LeftProperty, marqueeAnimation);
        }
        private void LoadUserDetails()
        {
            // Simulate fetching the logged-in user's name
            string usernameWithDomain = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            string[] parts = usernameWithDomain.Split('\\');
            string username = parts.Length > 1 ? parts[1] : usernameWithDomain;
            //string username = System.Security.Principal.WindowsIdentity.GetCurrent().Name; // Replace with actual logic to get the username
            UserDetails.Text = $"Welcome, {username}";
            Logger.Info($"IniConsolePage initialized by the user : {usernameWithDomain} ");

        }
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Logged out successfully!");
            // Add your logout logic here
            this.Close();
                        
        }
        private void SidebarToggle_Click(object sender, RoutedEventArgs e)
        {
            Sidebar.Visibility = Sidebar.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
            Logger.Info("Sidebar toggled.");
        }
        private void AddPackage_Click(object sender, RoutedEventArgs e)
        {
            Logger.Info("Navigating to AddPackagePage.");
            Sidebar.Visibility = Visibility.Hidden;
            MainContentArea.Navigate(new AddPackagePage());
        }
        private void INIConsole_Click(object sender, RoutedEventArgs e)
        {
            Logger.Info("Selected INIconsole Page");
            Sidebar.Visibility = Visibility.Hidden;

            if (MainContentArea.Content is not AddPackagePage addPage)
            {
                MessageBox.Show("Please open the Add Package Page and fill required fields before proceeding.", "Navigation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                Logger.Warn("INI Console access attempted without active AddPackagePage context.");
                return;
            }

            string productName = addPage.productNameTextBox.Text.Trim();
            string productVersion = addPage.fileVersionTextBox.Text.Trim();
            string drmBuild = addPage.drmBuildTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(productName) || string.IsNullOrWhiteSpace(productVersion))
            {
                MessageBox.Show("First, add the package before clicking on the INI Console Page.", "Missing Information", MessageBoxButton.OK, MessageBoxImage.Warning);
                Logger.Warn("Attempted to access INI Console Page without setting required fields.");
                return;
            }

            string basePath = PathManager.BasePackagePath;
            string productFolder = System.IO.Path.Combine(basePath, productName, productVersion, "Altiris");
            string supportFilesFolder = System.IO.Path.Combine(productFolder, drmBuild, "SupportFiles");

            Directory.CreateDirectory(productFolder);
            Directory.CreateDirectory(supportFilesFolder);

            Logger.Info($"Navigating to IniConsolePage for {productName} {productVersion}.");
            var iniConsolePage = new IniConsolePage(productFolder, supportFilesFolder);
            MainContentArea.Navigate(iniConsolePage);
        }
        private void CopyToolkit_Click(object sender, RoutedEventArgs e)
        {
            Sidebar.Visibility = Visibility.Hidden;
            Logger.Info("Navigating to Copy Toolkit page...");
            MainContentArea.Navigate(new CopyPackage());

        }
        private void ViewPackages_Click(object sender, RoutedEventArgs e)
        {
            Logger.Info("Navigating to PackageViewerPage");
            MainContentArea.Navigate(new PackageConsole.Pages.PackageViewerPage());
        }

        private void Testing_Click(object sender, RoutedEventArgs e)
        {
            Logger.Info("Navigating to Testing page...");
            Sidebar.Visibility = Visibility.Hidden;
            MainContentArea.Navigate(new AppDeploymentTestPage());
        }
        private void PreviousApps_Click(object sender, RoutedEventArgs e)
        {
            Logger.Info("Navigating to Previous Apps page...");
            Sidebar.Visibility = Visibility.Hidden;
            MainContentArea.Navigate(new PreviousApps());
        }
        private void Home_Click(object sender, RoutedEventArgs e)
        {
            Logger.Info("Navigating to Home page...");
            Sidebar.Visibility = Visibility.Hidden;

            MainContentArea.Navigate(new HomePage());
        }
        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            Logger.Info("Navigating to Feedback page...");
            Sidebar.Visibility = Visibility.Hidden;
            MainContentArea.Navigate(new FeedbackPage());
        }
        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            var helpWindow = new HelpWindow();
            helpWindow.Owner = this;
            helpWindow.ShowDialog();
        }

    }
}