﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using NLog;
using PackageConsole.Data;
using PackageConsole.Models;

namespace PackageConsole.Pages
{
    public partial class PackageViewerPage : Page
    {
        private List<PackageInfo> allPackages;
        private static readonly Logger Logger = LogManager.GetLogger(nameof(PackageViewerPage));
        public PackageViewerPage()
        {
            InitializeComponent();
            LoadPackages();
        }

        private void LoadPackages()
        {
            allPackages = SqlitePackageHelper.GetAllPackages();
            packageGrid.ItemsSource = allPackages;
            txtResultCount.Text = $"Results: {allPackages.Count}";
        }

        private void ApplyFilter_Click(object sender, RoutedEventArgs e)
        {
            var appKey = txtAppKeyIDFilter.Text.Trim().ToLower();
            var appName = txtAppNameFilter.Text.Trim().ToLower();
            var submittedBy = txtSubmittedByFilter.Text.Trim().ToLower();

            var filtered = allPackages.Where(p =>
                (string.IsNullOrEmpty(appKey) || (p.AppKeyID?.ToLower().Contains(appKey) ?? false)) &&
                (string.IsNullOrEmpty(appName) || (p.AppName?.ToLower().Contains(appName) ?? false)) &&
                (string.IsNullOrEmpty(submittedBy) || (p.SubmittedBy?.ToLower().Contains(submittedBy) ?? false))
            ).ToList();

            packageGrid.ItemsSource = filtered;
            txtResultCount.Text = $"Results: {filtered.Count}";
        }

        private void ClearFilter_Click(object sender, RoutedEventArgs e)
        {
            txtAppKeyIDFilter.Text = "";
            txtAppNameFilter.Text = "";
            txtSubmittedByFilter.Text = "";
            packageGrid.ItemsSource = allPackages;
            txtResultCount.Text = $"Results: {allPackages.Count}";
        }

        private void ExportCsv_Click(object sender, RoutedEventArgs e)
        {
            var data = packageGrid.ItemsSource as IEnumerable<PackageInfo>;
            if (data == null || !data.Any()) return;

            var sb = new StringBuilder();
            sb.AppendLine("AppKeyID,AppName,AppVersion,InstallerType,SubmittedBy,SubmittedOn");
            foreach (var p in data)
            {
                sb.AppendLine($"{p.AppKeyID},{p.AppName},{p.AppVersion},{p.InstallerType},{p.SubmittedBy},{p.SubmittedOn:yyyy-MM-dd HH:mm:ss}");
            }

            var fileName = $"packages_export_{DateTime.Now:yyyyMMdd_HHmmss}.csv";
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), fileName);
            File.WriteAllText(path, sb.ToString());
            MessageBox.Show($"CSV exported to desktop as {fileName}", "Export Complete");
        }

        private void ViewIni_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is PackageInfo selected)
            {
                var scrollViewer = new ScrollViewer { Content = new TextBlock { Text = selected.PackageIniText, TextWrapping = TextWrapping.Wrap }, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Width = 800, Height = 600 };
                var win = new Window { Title = $"INI for {selected.AppKeyID}", Content = scrollViewer, Owner = Application.Current.MainWindow, WindowStartupLocation = WindowStartupLocation.CenterOwner, SizeToContent = SizeToContent.WidthAndHeight };
                win.ShowDialog();
            }
        }
        private void AppKeyID_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is PackageInfo selected)
            {
                string basePath = PathManager.BasePackagePath;
                string productFolder = Path.Combine(basePath, selected.AppName, selected.AppVersion, "Altiris");
                string supportFilesFolder = Path.Combine(productFolder, "1.0", "SupportFiles");
                string toolkitPath = PathManager.ToolkitPath;

                try
                {
                    Directory.CreateDirectory(supportFilesFolder);

                    // Copy Toolkit folder (except 'Files')
                    foreach (string dir in Directory.GetDirectories(toolkitPath, "*", SearchOption.AllDirectories))
                    {
                        if (!dir.Contains("Files"))
                        {
                            string targetDir = dir.Replace(toolkitPath, Path.Combine(productFolder, "1.0"));
                            Directory.CreateDirectory(targetDir);
                            foreach (var file in Directory.GetFiles(dir))
                            {
                                string destFile = Path.Combine(targetDir, Path.GetFileName(file));
                                File.Copy(file, destFile, overwrite: true);
                            }
                        }
                    }

                    Logger.Info($"Navigating to IniConsolePage for AppKeyID {selected.AppKeyID}");
                    var iniConsole = new IniConsolePage(productFolder, supportFilesFolder);
                    NavigationService?.Navigate(iniConsole);
                }
                catch (Exception ex)
                {
                    Logger.Error(ex, "Failed to prepare folder structure for INI Console");
                    MessageBox.Show("Error loading INI Console: " + ex.Message);
                }
            }
        }

        private void DownloadIni_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is PackageInfo selected && !string.IsNullOrWhiteSpace(selected.PackageIniText))
            {
                var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), $"{selected.AppKeyID}.ini");
                File.WriteAllText(path, selected.PackageIniText);
                MessageBox.Show($"INI saved to desktop as {selected.AppKeyID}.ini", "Download Complete");
            }
        }
    }
}
