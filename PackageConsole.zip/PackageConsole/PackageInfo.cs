﻿using System;

namespace PackageConsole.Models
{
    public class PackageInfo
    {
        public string AppKeyID { get; set; }          // Primary Key
        public string AppName { get; set; }
        public string AppVersion { get; set; }
        public string ProductCode { get; set; }
        public string Vendor { get; set; }
        public string DRMBuild { get; set; }
        public string RebootOption { get; set; }
        public string InstallerType { get; set; }      // MSI / EXE
        public string InstallerFile { get; set; }
        public string SubmittedBy { get; set; }
        public DateTime SubmittedOn { get; set; }
        public string PackageIniText { get; set; }     // Full INI contents from IniConsolePage
    }
}
